/*
 * Look4Sat. Amateur radio satellite tracker and pass predictor.
 * Copyright (C) 2019-2026 Arty Bishop and contributors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.rtbishop.look4sat.core.domain.predict

data class OrbitalData(
    val name: String,
    val epoch: Double,
    val meanmo: Double,
    val eccn: Double,
    val incl: Double,
    val raan: Double,
    val argper: Double,
    val meanan: Double,
    val catnum: Int,
    val bstar: Double,
    val ndot: Double = 0.0
) {
    val xincl: Double = incl * DEG2RAD
    val xnodeo: Double = raan * DEG2RAD
    val omegao: Double = argper * DEG2RAD
    val xmo: Double = meanan * DEG2RAD
    val xno: Double = meanmo * TWO_PI / MIN_PER_DAY
    val orbitalPeriod: Double = MIN_PER_DAY / meanmo
    val isDeepSpace: Boolean = orbitalPeriod >= 225.0 // NearEarth (period < 225 min) or DeepSpace (period >= 225 min)
    fun getObject(): OrbitalObject = if (isDeepSpace) DeepSpaceObject(this) else NearEarthObject(this)

    /** Check if satellite has likely decayed by the given time. */
    fun hasDecayed(currentTimeMillis: Long): Boolean {
        if (ndot == 0.0) return false
        val currentDaynum = (currentTimeMillis - 315446400000L) / 86400000.0
        val epochDaynum = epochToDaynum(epoch)
        return CelestialComputer.hasDecayed(meanmo, ndot, epochDaynum, currentDaynum)
    }

    private fun epochToDaynum(epoch: Double): Double {
        var year = kotlin.math.floor(epoch * 1E-3)
        val day = (epoch * 1E-3 - year) * 1000.0
        year = if (year < 57) year + 2000 else year + 1900
        // daynum = days since 31 Dec 1979, Julian date of 31Dec79 = 2444238.5
        val jan1Jd = julianDateOfYear(year)
        return jan1Jd + day - 2444238.5
    }

    private fun julianDateOfYear(theYear: Double): Double {
        val aYear = theYear - 1
        val a = kotlin.math.floor(aYear / 100).toLong()
        val b = 2 - a + a / 4
        val i = kotlin.math.floor(365.25 * aYear).toLong()
        return i + (30.6001 * 14).toLong() + 1720994.5 + b
    }
}
